velocity = {
    "walk": 1,
    "tram": 2.5,
    "enllaç": 1,
    "acces": 1
}
colour = {
    "other": "black",
    "L1": "red",
    "L2": "darkviolet",
    "L3": "green",
    "L4": "gold",
    "L5": "blue",
    "L9N": "orangered",
    "L9S": "orangered",
    "L10N": "darkturquoise",
    "L10S": "darkturquoise",
    "L11": "greenyellow",
    "FM": "forestgreen"
}
resolution_x = 2000
resolution_y = 2000
